/**
 * Melodix - API & State Engine (Vanilla JS)
 */

// Mock Data API
const MUSIC_DATABASE = [
    { id: '1', title: 'Hương Mùa Hè', artist: 'Suni Hạ Linh', type: 'Pop', region: 'Asia', cover: 'https://images.unsplash.com/photo-1493225255756-d9584f8606e9?auto=format&fit=crop&w=800&q=80', audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' },
    { id: '2', title: 'Midnight City', artist: 'M83', type: 'Electronic', region: 'Europe', cover: 'https://images.unsplash.com/photo-1514525253344-f814d0743585?auto=format&fit=crop&w=800&q=80', audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3' },
    { id: '3', title: 'Everglow', artist: 'Coldplay', type: 'Pop', region: 'Europe', cover: 'https://images.unsplash.com/photo-1459749411177-042180ce673c?auto=format&fit=crop&w=800&q=80', audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3' },
    { id: '4', title: 'Lạc Trôi', artist: 'Sơn Tùng M-TP', type: 'Pop', region: 'Asia', cover: 'https://images.unsplash.com/photo-1516057121661-827435c25ede?auto=format&fit=crop&w=800&q=80', audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3' },
    { id: '5', title: 'Traditional Zen', artist: 'Kenji Suzuki', type: 'Traditional', region: 'Asia', cover: 'https://images.unsplash.com/photo-1528459199957-0ff28496a7f6?auto=format&fit=crop&w=800&q=80', audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3' },
    { id: '6', title: 'Clair de Lune', artist: 'Debussy', type: 'Cổ điển', region: 'Europe', cover: 'https://images.unsplash.com/photo-1507838153414-b4b713384a76?auto=format&fit=crop&w=800&q=80', audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3' },
    { id: '7', title: 'Deep Sea', artist: 'Oceanic', type: 'Ambient', region: 'Global', cover: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=800&q=80', audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3' },
    { id: '8', title: 'Neon Lights', artist: 'Synthwave', type: 'Electronic', region: 'US', cover: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&w=800&q=80', audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3' }
];

const POSTCARD_DATABASE = [
    { id: 'p1', title: 'Hoi An Ancient Town', location: 'Vietnam', img: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80' },
    { id: 'p2', title: 'Eiffel Tower Night', location: 'France', img: 'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?auto=format&fit=crop&w=800&q=80' },
    { id: 'p3', title: 'Fujisan Cherry Blossom', location: 'Japan', img: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80' },
    { id: 'p4', title: 'Swiss Alps Village', location: 'Switzerland', img: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=800&q=80' },
    { id: 'p5', title: 'Ha Long Bay Dawn', location: 'Vietnam', img: 'https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=800&q=80' },
    { id: 'p6', title: 'Berlin Wall Art', location: 'Germany', img: 'https://images.unsplash.com/photo-1520117003479-60b13f0adad4?auto=format&fit=crop&w=800&q=80' }
];

// App State
let appState = {
    currentSong: null,
    isPlaying: false,
    likedSongs: JSON.parse(localStorage.getItem('m_liked')) || [],
    user: JSON.parse(localStorage.getItem('m_user')) || null,
    playPromise: null
};

const audio = new Audio();

// Initialization
function init() {
    renderChartsPreview();
    renderPostcardList(POSTCARD_DATABASE);
    setupMusicPage();
    setupAuthDisplay();
    updatePlayerUI(); // Load last state
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function renderChartsPreview() {
    const container = document.getElementById('top-charts-preview');
    if (!container) return;
    
    container.innerHTML = MUSIC_DATABASE.slice(0, 6).map(s => `
        <div class="music-card" onclick="window.playSongById('${s.id}')">
            <div class="card-img-wrapper" style="position:relative; margin-bottom:12px;">
                <img src="${s.cover}" alt="${s.title}" style="width:100\%; aspect-ratio: 1; object-fit: cover; border-radius:12px;">
                <div class="card-play-overlay">
                    <i data-lucide="play" fill="currentColor"></i>
                </div>
            </div>
            <h4>${s.title}</h4>
            <p>${s.artist}</p>
        </div>
    `).join('');
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

function setupMusicPage() {
    const container = document.getElementById('music-container');
    if (!container) return;

    renderMusicList(MUSIC_DATABASE);

    // Search Engine
    const searchInput = document.getElementById('music-search');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const q = e.target.value.toLowerCase();
            
            // Filter Music
            const filteredMusic = MUSIC_DATABASE.filter(s => 
                s.title.toLowerCase().includes(q) || 
                s.artist.toLowerCase().includes(q) ||
                s.type.toLowerCase().includes(q)
            );
            renderMusicList(filteredMusic);

            // Filter Postcards
            const filteredPostcards = POSTCARD_DATABASE.filter(p => 
                p.title.toLowerCase().includes(q) || 
                p.location.toLowerCase().includes(q)
            );
            renderPostcardList(filteredPostcards);

            const searchStatus = document.getElementById('search-status');
            if (searchStatus) {
                if (q.length > 0) searchStatus.classList.remove('hidden');
                else searchStatus.classList.add('hidden');
            }
        });
    }

    const filters = document.querySelectorAll('.filter-pill');
    filters.forEach(btn => {
        btn.addEventListener('click', () => {
            filters.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const genre = btn.textContent.trim();
            if (genre === 'Tất cả') {
                renderMusicList(MUSIC_DATABASE);
            } else {
                const filtered = MUSIC_DATABASE.filter(s => s.type === genre);
                renderMusicList(filtered);
            }
        });
    });

    // Volume control
    const volumeSlider = document.querySelector('.volume-slider');
    let lastVolume = 1;

    if (volumeSlider) {
        // Set initial volume
        audio.volume = volumeSlider.value / 100;
        
        volumeSlider.addEventListener('input', (e) => {
            const val = e.target.value;
            audio.volume = val / 100;
            if (val > 0) lastVolume = val / 100;
            updateVolumeIcon(val);
        });
    }

    // Toggle mute on icon click
    const volumeContainer = document.querySelector('.player-right');
    if (volumeContainer) {
        volumeContainer.addEventListener('click', (e) => {
            // Only toggle if clicking the icon, not the slider
            if (e.target.closest('i') || e.target.closest('svg')) {
                if (audio.volume > 0) {
                    lastVolume = audio.volume;
                    audio.volume = 0;
                    if (volumeSlider) volumeSlider.value = 0;
                    updateVolumeIcon(0);
                } else {
                    audio.volume = lastVolume || 0.5;
                    if (volumeSlider) volumeSlider.value = audio.volume * 100;
                    updateVolumeIcon(audio.volume * 100);
                }
            }
        });
    }

    function updateVolumeIcon(val) {
        const volumeContainer = document.querySelector('.player-right');
        if (volumeContainer) {
            let iconName = 'volume-2';
            if (val == 0) iconName = 'volume-x';
            else if (val < 50) iconName = 'volume-1';
            
            const oldIcon = volumeContainer.querySelector('i, svg');
            if (oldIcon) {
                const newIcon = document.createElement('i');
                newIcon.setAttribute('data-lucide', iconName);
                oldIcon.replaceWith(newIcon);
                if (typeof lucide !== 'undefined') lucide.createIcons();
            }
        }
    }

    // Player controls with null checks
    const playToggle = document.getElementById('p-play-toggle');
    if (playToggle) playToggle.onclick = () => window.togglePlay();

    const likeBtn = document.getElementById('p-like');
    if (likeBtn) likeBtn.onclick = () => window.toggleLike();

    const downloadBtn = document.getElementById('p-download');
    if (downloadBtn) downloadBtn.onclick = () => window.downloadCurrent();
    
    const nextBtn = document.getElementById('p-next');
    if (nextBtn) nextBtn.onclick = () => playNext();

    const prevBtn = document.getElementById('p-prev');
    if (prevBtn) prevBtn.onclick = () => playPrev();
    
    // Smooth progress update
    audio.ontimeupdate = () => {
        const fill = document.getElementById('p-progress');
        if (fill) fill.style.width = (audio.currentTime / audio.duration * 100) + '%';
        const cur = document.getElementById('p-current');
        if (cur) cur.textContent = formatTime(audio.currentTime);
    };

    // Seek capability
    const progressBg = document.querySelector('.progress-bg');
    if (progressBg) {
        progressBg.addEventListener('click', (e) => {
            if (!audio.duration) return;
            const rect = progressBg.getBoundingClientRect();
            const pos = (e.clientX - rect.left) / rect.width;
            audio.currentTime = pos * audio.duration;
        });
    }

    audio.onloadedmetadata = () => {
        const total = document.getElementById('p-total');
        if (total) total.textContent = formatTime(audio.duration);
    };
}

function renderPostcardList(list) {
    const container = document.getElementById('postcard-grid-home');
    if (!container) return;
    
    if (list.length === 0) {
        container.innerHTML = `<p style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 40px;">Không tìm thấy postcard nào phù hợp.</p>`;
        return;
    }

    container.innerHTML = list.map(p => `
        <div class="postcard-card">
            <img src="${p.img}" alt="${p.title}">
            <div class="postcard-info">
                <h4>${p.title}</h4>
                <p><i data-lucide="map-pin"></i> ${p.location}</p>
            </div>
        </div>
    `).join('');
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

function playNext() {
    if (!appState.currentSong) return;
    const idx = MUSIC_DATABASE.findIndex(s => s.id === appState.currentSong.id);
    const next = MUSIC_DATABASE[(idx + 1) % MUSIC_DATABASE.length];
    window.playSongById(next.id);
}

function playPrev() {
    if (!appState.currentSong) return;
    const idx = MUSIC_DATABASE.findIndex(s => s.id === appState.currentSong.id);
    const prev = MUSIC_DATABASE[(idx - 1 + MUSIC_DATABASE.length) % MUSIC_DATABASE.length];
    window.playSongById(prev.id);
}

function renderMusicList(list) {
    const container = document.getElementById('music-container');
    if (!container) return;
    
    container.innerHTML = list.map(s => `
        <div class="music-card" onclick="window.playSongById('${s.id}')">
            <div class="card-img-wrapper" style="position:relative; margin-bottom:12px;">
                <img src="${s.cover}" alt="cover" style="width:100%; border-radius:12px;">
                <div class="card-play-overlay">
                    <i data-lucide="play" fill="currentColor"></i>
                </div>
            </div>
            <h4>${s.title}</h4>
            <p>${s.artist}</p>
        </div>
    `).join('');
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

async function playSongById(id) {
    const song = MUSIC_DATABASE.find(s => s.id === id);
    if (!song) return;

    if (appState.playPromise) {
        try { await appState.playPromise; } catch(e) {}
    }

    if (appState.currentSong?.id !== id) {
        appState.currentSong = song;
        audio.src = song.audio;
    }
    
    appState.playPromise = audio.play();
    try {
        await appState.playPromise;
        appState.isPlaying = true;
    } catch (err) {
        console.warn("Playback interrupted", err);
        appState.isPlaying = false;
    }
    updatePlayerUI();
}

async function togglePlay() {
    if (!appState.currentSong) return;
    
    if (appState.isPlaying) {
        audio.pause();
        appState.isPlaying = false;
    } else {
        appState.playPromise = audio.play();
        try {
            await appState.playPromise;
            appState.isPlaying = true;
        } catch (e) {
            console.warn("Playback error", e);
            appState.isPlaying = false;
        }
    }
    updatePlayerUI();
}

function updatePlayerUI() {
    const btn = document.getElementById('p-play-toggle');
    if (btn) btn.innerHTML = appState.isPlaying ? '<i data-lucide="pause"></i>' : '<i data-lucide="play"></i>';
    
    const title = document.getElementById('p-title');
    const artist = document.getElementById('p-artist');
    const cover = document.getElementById('p-cover');
    const likeBtn = document.getElementById('p-like');
    
    // Showcase update (at the end of main content)
    const showcase = document.getElementById('playing-showcase');
    
    if (appState.currentSong) {
        if (title) title.textContent = appState.currentSong.title;
        if (artist) artist.textContent = appState.currentSong.artist;
        if (cover) cover.src = appState.currentSong.cover;
        
        if (likeBtn) {
            const isLiked = appState.likedSongs.includes(appState.currentSong.id);
            likeBtn.style.color = isLiked ? 'var(--primary)' : 'inherit';
        }

        if (showcase) {
            showcase.classList.remove('hidden');
            showcase.innerHTML = `
                <div class="showcase-content">
                    <div class="showcase-img">
                        <img src="${appState.currentSong.cover}" alt="cover">
                        <div class="wave-animation ${appState.isPlaying ? 'active' : ''}">
                            <span></span><span></span><span></span><span></span>
                        </div>
                    </div>
                    <div class="showcase-info">
                        <span class="badge" style="display:inline-block; margin-bottom:12px;">ĐANG PHÁT</span>
                        <h3>${appState.currentSong.title}</h3>
                        <p>${appState.currentSong.artist}</p>
                        <button class="btn btn-primary" onclick="window.togglePlay()">
                             ${appState.isPlaying ? 'TẠM DỪNG' : 'TIẾP TỤC NGHE'}
                        </button>
                    </div>
                </div>
            `;
        }
    }
    
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function toggleLike() {
    if (!appState.currentSong) return;
    const id = appState.currentSong.id;
    if (appState.likedSongs.includes(id)) {
        appState.likedSongs = appState.likedSongs.filter(item => item !== id);
    } else {
        appState.likedSongs.push(id);
    }
    localStorage.setItem('m_liked', JSON.stringify(appState.likedSongs));
    updatePlayerUI();
}

function downloadCurrent() {
    if (!appState.currentSong) return;
    const link = document.createElement('a');
    link.href = appState.currentSong.audio;
    link.download = `${appState.currentSong.title}.mp3`;
    link.click();
}

function formatTime(s) {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec < 10 ? '0' : ''}${sec}`;
}

function setupAuthDisplay() {
    const display = document.getElementById('user-display');
    if (appState.user && display) {
        display.textContent = appState.user.name;
        display.href = "#";
    }
}

// Export functions to window scope for inline event handlers and global access
window.playSongById = playSongById;
window.togglePlay = togglePlay;
window.toggleLike = toggleLike;
window.downloadCurrent = downloadCurrent;

// Run app
init();
